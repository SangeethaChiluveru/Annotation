package com.demo.model;

public class Address {

}
