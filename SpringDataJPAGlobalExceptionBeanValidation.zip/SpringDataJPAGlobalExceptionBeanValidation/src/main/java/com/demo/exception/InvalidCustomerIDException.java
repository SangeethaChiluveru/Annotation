package com.demo.exception;

public class InvalidCustomerIDException {

}
