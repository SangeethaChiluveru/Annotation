package com.demo.exception;

public class CustomerNotFoundException {

}
